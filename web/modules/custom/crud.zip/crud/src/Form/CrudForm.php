<?php

namespace Drupal\crud\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Database\Database;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;


class CrudForm extends FormBase {

    public function getFormId()
    {
        return 'crud_form';
    }
    public function buildForm(array $form, FormStateInterface $form_state)
    {
        $conn = Database::getConnection();
        $record = array();
        if (isset($_GET['num'])) {
            $record = $conn->select('crud_table', 'm')
            ->condition('id', $_GET['num'])
            ->fields('m')->execute()->fetchAll();
            
        }
        // kint($record[0]->gender);
        

        $form['CRUD Form'] = [
            '#type' => 'description',
            '#open' => 'false'
        ];
        $form['name'] = [
            '#type' => 'textfield',
            '#title'=> $this->t('Name'),
            '#default_value' => (isset($record[0]->name) && $_GET['num']) ? $record[0]->name:'',
        ];
        $form['element']=[
            '#type'=>'markup',
            '#markup'=>"<div class = nameerr></div>"];

        $form['phone_number'] = [
            '#type' => 'textfield',
            '#title'=> $this->t('Phone Number'),
            '#default_value' => (isset($record[0]->number) && $_GET['num']) ? $record[0]->number:'',
        ];
        $form['email'] = [
            '#type' => 'email',
            '#title'=> $this->t('Email'),
            '#default_value' => (isset($record[0]->email, $_GET['num'])) ? $record[0]->email:'',
        ];
        $form['gender'] = [
            '#type' => 'radios',
            '#title'=> $this->t('Gender'),
            '#default_value' => (isset($record[0]->gender)&&($_GET['num'])) ? $record[0]->gender: NULL,
            '#options' => [
                0 => 'Male',
                1 => 'Female'
            ]
        ];
        $form['submit'] = [
            '#type' => 'submit',
            '#value'=> $this->t('Save'),
            // '#ajax' => ['callback' => '::validation']
        ];
        $form['#attached']['library'][] = 'crud/crud_js';
        return $form;
    }
    
    public function submitForm(array &$form, FormStateInterface $form_state)
    {
        $fields = $form_state->getValues();
        $data = [
            'name' => $fields['name'],
            'number' => $fields['phone_number'],
            'email' => $fields['email'],
            'gender' => $fields['gender']
        ];

        if (isset($_GET['num'])) {
            $query = \Drupal::database();
            $query->update('crud_table')
                ->fields($data)
                ->condition('id', $_GET['num'])
                ->execute();
                \Drupal::messenger()->addStatus("succesfully updated");
            $form_state->setRedirect('crud.display');
  
        }
        else {
            
        
        $conn = Database::getConnection();
        $conn->insert('crud_table')->fields($data)->execute();
        // \Drupal::messenger()->addStatus("succesfully saved");
        $response = new RedirectResponse("/crud-display");
        $response->send();
        }
    }
}