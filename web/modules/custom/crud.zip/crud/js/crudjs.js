(function ($) {
    $(document).ready(function() {
        alert('Test');
    Drupal.behaviors.myBehavior = {
      attach: function (context, settings) {
        $('#crud_form').submit(function (event) {
            alert('submitted');
            if ($('#edit-name').val() == '') {
                $('.nameerr').text('This field is required');
                return false;
              }
        });
      }
    };
    });
  })(jQuery);